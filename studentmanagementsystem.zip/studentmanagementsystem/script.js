// Array to hold student objects
let students = [];

// Function to prompt user for student details
function getStudentDetails() {
    const numStudents = parseInt(document.getElementById("numStudents").value);
    
    for (let i = 0; i < numStudents; i++) {
        const name = prompt("Enter name of student " + (i + 1) + ":");
        const age = prompt("Enter age of student " + (i + 1) + ":");
        const grade = prompt("Enter grade of student " + (i + 1) + ":");
        
        // Create a student object and push it to the students array
        const student = {
            name: name,
            age: parseInt(age),
            grade: grade
        };
        students.push(student);
    }
}

// Function to view students in a table format
function viewStudents() {
    const studentList = document.getElementById("studentList");
    studentList.innerHTML = ""; // Clear existing content

    if (students.length === 0) {
        studentList.innerHTML = "<tr><td colspan='3'>No students available. Please add students.</td></tr>";
        return;
    }

    students.forEach(student => {
        studentList.innerHTML += `<tr>
            <td>${student.name}</td>
            <td>${student.age}</td>
            <td>${student.grade}</td>
        </tr>`;
    });
}

// Function to sort students by age
function sortStudents() {
    students.sort((a, b) => b.age - a.age); // Sort in ascending order of age
    viewStudents(); // Refresh the view to show sorted students
}

// Function to delete the last student
function deleteStudent() {
    if (students.length > 0) {
        students.pop(); // Remove the last student
        viewStudents(); // Refresh the view
    } else {
        alert("No students to delete.");
    }
}

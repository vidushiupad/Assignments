package com.hexaware.ShopSmart.exceptions;

public class InsufficientPaymentException extends Exception{
	public InsufficientPaymentException(String message) {
		super(message);
	}

}

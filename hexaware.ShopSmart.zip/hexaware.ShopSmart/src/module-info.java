/**
 * 
 */
/**
 * 
 */
module ShopSmart {
	requires java.sql;
}